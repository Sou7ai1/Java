package app;


import vehicule.*;

import java.util.GregorianCalendar;
import java.util.Scanner;

public class CarCareApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create a Car object
        
        
        System.out.println("Enter car model(from these options: Porsche, Audi,Volkswagen, BMW, Mercedes_Benz)");
        Model model = Model.valueOf(scanner.nextLine().toUpperCase());
        System.out.print("Please enter make");
        String make = scanner.nextLine();
        System.out.print("Please enter gearboxTyp ");
        String gearboxType = scanner.nextLine();
        System.out.print("Please enter number of doors ");
        int numberOfDoors = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Please enter the type ");
        String type = scanner.nextLine();
        System.out.print("Please enter the year ");
        int year = scanner.nextInt();
        scanner.nextLine();

        Car car = new Car(model, make, gearboxType, numberOfDoors, type, year);
        System.out.println("Car object created:");
        System.out.println(car);

        // Create a Post object
        
        System.out.println("Enter post content:");
        String postContent = scanner.nextLine();
        GregorianCalendar dateAndTime = new GregorianCalendar();
        
        Post post = new Post(dateAndTime, postContent);
        System.out.println("Post object created:");
        System.out.println(post.toString());

        scanner.close();
    }
}
