package account;

public class Inbox {
	
	
	
	public Message list_of_message;
	

	public Inbox(Message list_of_message) {
		
		this.list_of_message = list_of_message;
	}

	public void searchMessage() {
        
    }

    public void sortMessage() {
        
    }

    public void deleteMessage() {
       
    }

	@Override
	public String toString() {
		return "Inbox [list_of_message=" + list_of_message + "]";
	}
}
