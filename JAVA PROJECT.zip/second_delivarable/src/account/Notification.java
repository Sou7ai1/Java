package account;

import java.util.GregorianCalendar;

public class Notification {
	public GregorianCalendar DateAndTime;
    
    public String content;

    public Notification( GregorianCalendar DateAndTime, String content) {
        this.DateAndTime = DateAndTime;
        
        this.content = content;
    }

	@Override
	public String toString() {
		return "Notification [date=" + DateAndTime + ", content=" + content + "]";
	}
}
