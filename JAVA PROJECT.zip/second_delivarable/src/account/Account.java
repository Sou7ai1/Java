package account;

public class Account {
    public String email;
    private String password;

    public Account(String email, String password) {
        this.email = email;
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean authenticate(String email, String password) {
        return this.email.equals(email) && this.password.equals(password);
    }

	@Override
	public String toString() {
		return "Account [email=" + email + ", password=" + password + "]";
	}
}
