package account;

import java.util.GregorianCalendar;

public class Message {
    public GregorianCalendar dateAndTime;
    public String message;

    public Message(GregorianCalendar dateAndTime, String message) {
        this.dateAndTime = dateAndTime;
        this.message = message;
    }

	@Override
	public String toString() {
		return "Message [dateAndTime=" + dateAndTime + ", message=" + message + "]";
	}
}
