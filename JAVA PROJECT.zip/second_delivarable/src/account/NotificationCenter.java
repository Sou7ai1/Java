package account;

public class NotificationCenter {
	
	
	public Notification n;
	
	
    @Override
	public String toString() {
		return "NotificationCenter [n=" + n + "]";
	}

	public NotificationCenter(Notification n) {
		this.n = n;
	}

	public void viewNotification() {
        
		
    }

    public void removeNotification() {
       
    	
    }
}
