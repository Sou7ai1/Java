package vehicule;

import java.util.GregorianCalendar;

public class Post {
    public GregorianCalendar dateAndTime;
    public String post;

    public Post(GregorianCalendar dateAndTime, String post) {
        this.dateAndTime = dateAndTime;
        this.post = post;
    }

    public void updatePost(String post) {
        this.post = post;
    }

	@Override
	public String toString() {
		return "Post [date=" +(dateAndTime.get(GregorianCalendar.MONTH)+1)+"/"+dateAndTime.get(GregorianCalendar.DAY_OF_MONTH)
		+"/" +dateAndTime.get(GregorianCalendar.YEAR) +	
		" ,time= " +dateAndTime.get(GregorianCalendar.HOUR_OF_DAY)+":"+dateAndTime.get(GregorianCalendar.MINUTE)
		+":"+dateAndTime.get(GregorianCalendar.SECOND)+", post=" + post + "]";
	}
}
