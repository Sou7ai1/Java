package vehicule;


public enum Model {
	BMW, PORSCHE,AUDI,VOLKSWAGEN,MERCEDES
}
