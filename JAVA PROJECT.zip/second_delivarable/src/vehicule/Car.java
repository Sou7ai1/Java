package vehicule;

public class Car {
    public Model model;
    public String make;
    public String gearboxType;
    public int numberOfDoors;
    public String type;
    public int year;
    
    public Car(Model model, String make, String gearboxType, int numberOfDoors, String type, int year) {
        this.model = model;
        this.make = make;
        this.gearboxType = gearboxType;
        this.numberOfDoors = numberOfDoors;
        this.type = type;
        this.year = year;
    }

    public void updateCar(Model model, String make, String gearboxType, int numberOfDoors, String type, int year) {
        this.model = model;
        this.make = make;
        this.gearboxType = gearboxType;
        this.numberOfDoors = numberOfDoors;
        this.type = type;
        this.year = year;
    }

    public void addCar() {
        
    }

    public void hideCar() {
        
    }

	@Override
	public String toString() {
		return "Car [model=" + model + ", make=" + make + ", gearboxType=" + gearboxType + ", numberOfDoors="
				+ numberOfDoors + ", type=" + type + ", year=" + year + "]";
	}

 
}
