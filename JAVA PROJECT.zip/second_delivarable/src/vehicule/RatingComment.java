package vehicule;

import java.util.GregorianCalendar;

public class RatingComment {
    public int rating;
    public String comment;
    public GregorianCalendar dateTime;

    public RatingComment(int rating, String comment, GregorianCalendar dateTime) {
        this.rating = rating;
        this.comment=comment;
        this.dateTime = dateTime;
    
}
    
    public void rate() {
    	
    }

	@Override
	public String toString() {
		return "RatingComment [rating=" + rating + ", comment=" + comment + ", dateTime=" + dateTime + "]";
	}
}
