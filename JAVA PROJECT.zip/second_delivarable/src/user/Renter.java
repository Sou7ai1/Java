package user;

public class Renter extends User {
    public Renter(String name, int age, String profession, String address) {
        super(name, age, profession, address);
    }

    public void viewTopRatedOwners() {
       
    }

    public void rentRequest() {
        
    }
}
