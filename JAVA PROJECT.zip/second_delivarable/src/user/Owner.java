package user;

public class Owner extends User {
	
	public int price;
    public Owner(String name, int age, String profession, String address, int price) {
        super(name, age, profession, address);
        this.price=price;
    }

    public void updatePrice(int price) {
        this.price=price;
    }

    public void approveRequest() {
        
    }

    public void refuseRequest() {
        
    }
}
