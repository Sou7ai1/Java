package user;
import account.Account;
public class User {
    public String name;
    public int age;
    public String profession;
    public String address;
    public Account A;
    
    public User(String name, int age, String profession, String address) {
        this.name = name;
        this.age = age;
        this.profession = profession;
        this.address = address;
        
    }

    public void updateInfo(String name, int age, String profession, String address) {
        this.name = name;
        this.age = age;
        this.profession = profession;
        this.address = address;
    }

   

	@Override
	public String toString() {
		return "User [name=" + name + ", age=" + age + ", profession=" + profession + ", address=" + address + "]";
	}

  
}
